# -*- coding: utf-8 -*-
"""
求职咨询论坛数据与业务逻辑
=================================
文章列表 / 详情 / 评论 / 点赞 / 分类
"""
from datetime import datetime

FORUM_CATEGORIES = ["全部", "求职攻略", "转行经验", "薪资谈判", "职场生存", "职场热点", "面试技巧"]

FORUM_ARTICLES = [
    {
        "id": "art_001",
        "title": "2026年秋招指南：应届毕业生如何在金九银十脱颖而出",
        "author": "职场老司机",
        "author_avatar": "👨‍💼",
        "category": "求职攻略",
        "summary": "金九银十秋招季已经到来，作为应届生的你准备好了吗？本文从简历优化、笔试准备、面试技巧三个维度，帮你全面提升秋招竞争力。",
        "content": """<h2>一、简历优化：让HR在3秒内记住你</h2>
<p>简历是求职的敲门砖。HR平均浏览一份简历的时间只有3-5秒，如何在这短短几秒内抓住眼球？</p>
<ul>
<li><strong>STAR法则</strong>：描述项目经历时，用情境(Situation)、任务(Task)、行动(Action)、结果(Result)的结构</li>
<li><strong>量化成果</strong>：少说"负责XX工作"，多说"将XX指标提升了30%"</li>
<li><strong>一页纸原则</strong>：应届生简历尽量控制在一页内，突出重点</li>
<li><strong>关键词匹配</strong>：仔细阅读JD，把岗位要求的关键词自然地融入简历</li>
</ul>

<h2>二、笔试准备：刷题是基础</h2>
<p>无论是技术岗还是非技术岗，笔试都是绕不开的环节。</p>
<ul>
<li>技术岗：LeetCode 前200道高频题至少刷2遍，重点掌握数组、链表、树、动态规划</li>
<li>产品岗：练习产品分析题、竞品对比、需求设计</li>
<li>运营岗：熟悉数据分析方法、活动策划框架</li>
<li>通用：行测题（图形推理、数量关系、言语理解）每天练一套</li>
</ul>

<h2>三、面试技巧：自信 + 真诚 + 准备</h2>
<p>面试不是考试，而是双向选择的过程。</p>
<ol>
<li><strong>自我介绍</strong>：准备1分钟和3分钟两个版本，突出亮点</li>
<li><strong>项目深挖</strong>：对简历上的每个项目都要能讲清楚背景、难点、解决方案、收获</li>
<li><strong>反问环节</strong>：提前准备3-5个有深度的问题问面试官，体现你的思考</li>
<li><strong>结束后复盘</strong>：每次面试后及时记录问题和不足，不断改进</li>
</ol>

<h2>四、心态管理</h2>
<p>秋招是一场马拉松，不是百米冲刺。被拒是常态，offer是惊喜。保持良好的心态，相信自己的努力终会有回报。</p>
<p><strong>记住：你不需要拿到所有offer，只需要拿到那一个最适合你的。</strong></p>""",
        "cover": "📝",
        "views": 3256,
        "likes": 128,
        "comments_count": 4,
        "publish_time": "2026-09-10 14:30",
        "tags": ["秋招", "应届生", "简历", "面试技巧"],
    },
    {
        "id": "art_002",
        "title": "从0到1：非科班转行程序员的完整路线图",
        "author": "码农老张",
        "author_avatar": "🧑‍💻",
        "category": "转行经验",
        "summary": "很多人问我：非计算机专业能转行做程序员吗？答案是肯定的。但转行不是一时冲动，需要系统规划和持续努力。本文分享我的转行之路。",
        "content": """<h2>一、先想清楚：你真的适合转行吗？</h2>
<p>在开始之前，先问自己几个问题：</p>
<ul>
<li>你对编程有兴趣吗？还是只因为"程序员工资高"？</li>
<li>你能接受持续学习吗？技术栈更新很快，不进则退</li>
<li>你的优势在哪里？是逻辑思维强？还是沟通能力好？</li>
<li>你能承受至少6个月的高强度学习吗？</li>
</ul>
<p>如果以上答案都是肯定的，那么欢迎加入程序员大家庭！</p>

<h2>二、选方向：前端/后端/测试/运维/数据分析？</h2>
<p>不同方向的入门门槛和学习曲线差别很大。新手推荐从前端入门：视觉反馈强，成就感来得快，就业机会多。</p>

<h2>三、学习路线：6个月入门计划</h2>
<h3>第1-2个月：打基础</h3>
<ul>
<li>HTML/CSS/JavaScript 三件套</li>
<li>跟着教程做3-5个小项目（个人主页、todo list、计算器等）</li>
<li>熟悉 Git 基本操作</li>
</ul>
<h3>第3-4个月：学框架</h3>
<ul>
<li>选一个框架深入学习（Vue 或 React）</li>
<li>学习 Node.js 基础，了解后端原理</li>
<li>做一个完整的前后端项目</li>
</ul>
<h3>第5-6个月：求职准备</h3>
<ul>
<li>整理作品集，GitHub 持续更新</li>
<li>刷面试题（JS基础、CSS、框架原理、算法）</li>
<li>投递简历，从小公司开始积累面试经验</li>
</ul>

<h2>四、避坑指南</h2>
<ul>
<li>❌ 不要贪多求全：精通一门比"什么都会一点"强得多</li>
<li>❌ 不要只看视频不动手：编程是练出来的，不是看出来的</li>
<li>❌ 不要闭门造车：多逛技术社区，多交同行朋友</li>
<li>✅ 要做项目：项目经验是转行求职的核心竞争力</li>
<li>✅ 要写博客：输出是最好的学习方式</li>
</ul>""",
        "cover": "🚀",
        "views": 5678,
        "likes": 342,
        "comments_count": 3,
        "publish_time": "2026-09-08 09:15",
        "tags": ["转行", "前端", "学习路线", "经验分享"],
    },
    {
        "id": "art_003",
        "title": "谈薪技巧：如何让你的offer薪资上浮20%",
        "author": "HR小姐姐",
        "author_avatar": "👩‍💼",
        "category": "薪资谈判",
        "summary": "拿到offer只是第一步，谈薪才是决定你钱包厚度的关键。作为从业5年的HR，我来告诉你谈薪的正确姿势。",
        "content": """<h2>一、谈薪前的准备</h2>
<h3>1. 了解市场行情</h3>
<p>谈薪不是漫天要价，要基于市场水平。可以通过BOSS直聘、猎聘、脉脉、看准网等渠道了解。</p>
<h3>2. 明确自己的底线和目标</h3>
<ul>
<li><strong>底线薪资</strong>：低于这个数就不去，心里要有数</li>
<li><strong>目标薪资</strong>：你期望拿到的合理薪资</li>
<li><strong>惊喜薪资</strong>：如果给这么多，其他都不用谈了直接去</li>
</ul>

<h2>二、谈薪的最佳时机</h2>
<p><strong>永远不要先出价！</strong></p>
<p>如果HR问你期望薪资，不要直接说数字。可以这样回答："我更看重的是这个岗位的发展机会和公司平台。薪资方面我相信公司会有合理的薪酬体系，想先了解一下公司这边的薪资范围是多少？"</p>

<h2>三、谈薪核心策略</h2>
<ul>
<li>用"总包"代替"月薪"（基本工资+年终奖+股票+签字费+福利）</li>
<li>拿其他offer当筹码（但不要撒谎虚报）</li>
<li>突出你的价值：核心技能、项目经验、能带来的资源</li>
</ul>

<h2>四、最后的提醒</h2>
<ul>
<li>谈薪是正常的商业行为，不要不好意思</li>
<li>入职后的涨薪通常基于base的百分比，起薪高能赢在起跑线</li>
<li>但也不要唯薪资论，平台、团队、发展空间同样重要</li>
</ul>""",
        "cover": "💰",
        "views": 8921,
        "likes": 567,
        "comments_count": 3,
        "publish_time": "2026-09-05 16:45",
        "tags": ["谈薪", "offer", "薪资谈判", "职场经验"],
    },
    {
        "id": "art_004",
        "title": "职场新人必看：入职前3个月如何快速站稳脚跟",
        "author": "老王聊职场",
        "author_avatar": "👔",
        "category": "职场生存",
        "summary": "刚入职的前三个月是试用期，也是你给公司留下第一印象的关键期。如何快速融入团队、证明自己的价值？这篇文章给你答案。",
        "content": """<h2>一、第一周：熟悉环境，建立连接</h2>
<ul>
<li>记住每个人的名字和职位</li>
<li>了解公司"潜规则"（加班文化、沟通方式）</li>
<li>找个靠谱的mentor</li>
</ul>

<h2>二、第一个月：多听多看少说话</h2>
<ul>
<li>主动学习，不懂就问（但先自己查过再问）</li>
<li>做好向上管理：主动汇报进度</li>
<li>同一个问题不要问第二遍，记下来</li>
</ul>

<h2>三、第二个月：开始产出，小步快跑</h2>
<ul>
<li>从简单任务开始建立信任</li>
<li>按时交付，说到做到</li>
<li>主动承担，不要等活干</li>
</ul>

<h2>四、第三个月：证明价值，争取转正</h2>
<ul>
<li>梳理你的成果（用数据说话）</li>
<li>和领导做一次正式沟通</li>
<li>表达你想留下来的意愿</li>
</ul>

<h2>五、职场新人避坑清单</h2>
<p>✅ 要做的事：守时守信、积极主动、多问多记、及时反馈、保持学习</p>
<p>❌ 不要做的事：迟到、摸鱼、八卦、抱怨、甩锅</p>""",
        "cover": "🎯",
        "views": 4321,
        "likes": 234,
        "comments_count": 0,
        "publish_time": "2026-09-03 11:20",
        "tags": ["职场新人", "试用期", "入职攻略", "向上管理"],
    },
    {
        "id": "art_005",
        "title": "35岁危机是伪命题吗？聊聊IT行业的中年焦虑",
        "author": "架构师老王",
        "author_avatar": "🧓",
        "category": "职场热点",
        "summary": "35岁危机、程序员吃青春饭...这些话题每隔一段时间就会火一次。作为一个38岁还在写代码的老程序员，我想聊聊我的真实感受。",
        "content": """<h2>一、先讲结论：35岁危机是真实存在的</h2>
<p>35岁之后，求职市场确实会变窄。很多公司的初级岗位默认不会考虑35岁以上的候选人。但这不意味着你35岁就会失业。</p>

<h2>二、为什么会有"35岁危机"？</h2>
<ul>
<li>体力和精力下降</li>
<li>薪资倒挂：你工作10年工资是新人的两三倍，但做的事可能差不多</li>
<li>技术迭代快：不学习就被淘汰</li>
</ul>

<h2>三、如何破局？5条建议</h2>
<ol>
<li><strong>从技术执行转向技术决策</strong>：架构设计、技术选型、解决复杂问题</li>
<li><strong>积累行业经验</strong>：不要频繁换行业，深耕一个赛道</li>
<li><strong>发展第二曲线</strong>：技术博客、开源、咨询、投资理财</li>
<li><strong>管理好健康和财务</strong>：定期体检、存应急基金、买保险</li>
<li><strong>保持学习，但要有选择地学</strong>：深耕一个领域+关注一个趋势+学一个软技能</li>
</ol>

<h2>四、写在最后</h2>
<p>35岁不是终点，只是人生的中场。年轻时靠体力和冲劲，中年后靠经验和智慧。</p>
<p>与其焦虑"35岁怎么办"，不如从今天开始行动。种一棵树最好的时间是十年前，其次是现在。</p>""",
        "cover": "💭",
        "views": 12456,
        "likes": 876,
        "comments_count": 2,
        "publish_time": "2026-09-01 08:00",
        "tags": ["35岁危机", "职场焦虑", "职业规划", "经验分享"],
    },
    {
        "id": "art_006",
        "title": "面试官视角：我是怎么在30秒内判断一个候选人的",
        "author": "面试官老李",
        "author_avatar": "🎤",
        "category": "面试技巧",
        "summary": "作为一个面试了500+候选人的技术面试官，其实前30秒我心里就基本有数了。想知道面试官都在观察什么吗？",
        "content": """<h2>一、30秒判断的是什么？不是技术</h2>
<p>前30秒我在看的是：这个人"正常"吗？沟通起来不费劲、思路清晰、态度积极。这些特质决定了能不能融入团队。</p>

<h2>二、我会观察哪些细节？</h2>
<h3>1. 进门第一印象（5秒）</h3>
<p>穿着整洁、精神状态好、主动打招呼。</p>
<h3>2. 自我介绍（前10秒）</h3>
<p>说话流畅吗？有逻辑吗？时间把控如何？</p>
<h3>3. 第一个问题（前15秒）</h3>
<p>是直接回答还是先思考？不会就说不会还是硬编？</p>

<h2>三、加分项和减分项</h2>
<p>➕ 加分：主动打招呼有礼貌、眼神交流坐姿端正、回答有条理分点说、诚实说不会、主动问问题</p>
<p>➖ 减分：迟到不解释、眼神躲闪小动作多、答非所问绕圈子、不懂装懂瞎编、完全没问题</p>

<h2>四、给候选人的建议</h2>
<ol>
<li>认真准备：自我介绍、项目介绍、面试题提前演练</li>
<li>保持真诚：不会就说不会，别装</li>
<li>主动沟通：把面试当成交流，不是考试</li>
<li>展示热情：对技术和岗位的热情是会传染的</li>
</ol>""",
        "cover": "🎙️",
        "views": 6789,
        "likes": 423,
        "comments_count": 0,
        "publish_time": "2026-08-28 15:30",
        "tags": ["面试技巧", "面试官视角", "求职经验"],
    },
]

FORUM_COMMENTS = {
    "art_001": [
        {"id": "c001", "author": "找工作的小明", "avatar": "😀", "content": "写得太好了！正好在准备秋招，收藏了。请问非计算机专业学生秋招有机会进大厂吗？", "time": "2026-09-10 15:20", "likes": 12},
        {"id": "c002", "author": "职场老司机", "avatar": "👨‍💼", "content": "回复@找工作的小明：有机会的！大厂更看重潜力和基础。建议先把数据结构和算法打好基础，刷够LeetCode。", "time": "2026-09-10 16:00", "likes": 28},
        {"id": "c003", "author": "考研党", "avatar": "📚", "content": "想问一下，现在大环境下是考研好还是直接工作好呀？好纠结...", "time": "2026-09-11 09:15", "likes": 8},
        {"id": "c004", "author": "产品小周", "avatar": "🧑‍💻", "content": "STAR法则真的很有用！我之前面试用这个方法，通过率明显提高了。推荐大家都试试。", "time": "2026-09-11 14:30", "likes": 15},
    ],
    "art_002": [
        {"id": "c005", "author": "转行成功", "avatar": "🎉", "content": "我就是非科班转行前端的，学了8个月上岸了，现在月薪18K。坚持就是胜利！", "time": "2026-09-08 10:30", "likes": 45},
        {"id": "c006", "author": "30岁想转行", "avatar": "😅", "content": "30岁了还能转行吗？现在做运营，感觉没发展，想去学Python做数据分析...", "time": "2026-09-08 12:15", "likes": 6},
        {"id": "c007", "author": "码农老张", "avatar": "🧑‍💻", "content": "回复@30岁想转行：30岁不晚！数据分析对转行挺友好的，建议先业余学3个月确认兴趣。", "time": "2026-09-08 14:00", "likes": 23},
    ],
    "art_003": [
        {"id": "c008", "author": "刚拿offer", "avatar": "💰", "content": "亲测有效！上周用楼主说的方法谈薪，从18K谈到了22K，太感谢了！", "time": "2026-09-06 09:00", "likes": 67},
        {"id": "c009", "author": "害羞的菜鸟", "avatar": "🙈", "content": "我就是不好意思谈薪的那种人...每次HR说多少就是多少，感觉亏了好多。", "time": "2026-09-06 11:20", "likes": 34},
        {"id": "c010", "author": "HR小姐姐", "avatar": "👩‍💼", "content": "回复@害羞的菜鸟：其实HR也希望你谈薪的，说明你对自己有信心。", "time": "2026-09-06 14:00", "likes": 56},
    ],
    "art_005": [
        {"id": "c011", "author": "34岁程序员", "avatar": "😰", "content": "正好34岁，看到这篇文章太及时了。最近确实有点焦虑，感觉自己技术提升很慢。", "time": "2026-09-02 08:30", "likes": 89},
        {"id": "c012", "author": "架构师老王", "avatar": "🧓", "content": "回复@34岁程序员：别焦虑。建议先梳理自己的优势和方向，选一条路深耕比什么都学一点强。", "time": "2026-09-02 10:15", "likes": 45},
    ],
}


def get_article_list(category="全部", keyword="", page=1, size=10):
    articles = FORUM_ARTICLES[:]
    if category and category != "全部":
        articles = [a for a in articles if a["category"] == category]
    if keyword:
        kw = keyword.lower()
        articles = [a for a in articles
                    if kw in a["title"].lower() or kw in a["summary"].lower()]
    articles.sort(key=lambda a: a["publish_time"], reverse=True)
    total = len(articles)
    total_pages = (total + size - 1) // size
    start = (page - 1) * size
    end = min(start + size, total)
    return {
        "list": articles[start:end],
        "total": total,
        "page": page,
        "size": size,
        "totalPages": total_pages,
        "categories": FORUM_CATEGORIES,
    }


def get_article_detail(article_id):
    for a in FORUM_ARTICLES:
        if a["id"] == article_id:
            a["views"] += 1
            return a
    return None


def get_comments(article_id):
    return FORUM_COMMENTS.get(article_id, [])


def add_comment(article_id, username, content):
    article = get_article_detail(article_id)
    if not article:
        return None
    if article_id not in FORUM_COMMENTS:
        FORUM_COMMENTS[article_id] = []
    comment = {
        "id": "c" + str(len(FORUM_COMMENTS[article_id]) + 100).zfill(3),
        "author": username,
        "avatar": "😊",
        "content": content,
        "time": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "likes": 0,
    }
    FORUM_COMMENTS[article_id].append(comment)
    article["comments_count"] += 1
    return comment


def like_article(article_id):
    for a in FORUM_ARTICLES:
        if a["id"] == article_id:
            a["likes"] += 1
            return True
    return False
