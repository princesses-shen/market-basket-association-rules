#!/bin/bash
# VM 开机自启: Hadoop -> HBase -> Thrift -> Spring Boot -> predict
# 顺序很关键: HBase 依赖 HDFS, Thrift 依赖 HBase, Spring Boot 依赖 HBase+Thrift, predict 独立
# 日志统一写 ~/autostart.log；目录一律用 $HOME，换用户名不用改脚本
LOG="$HOME/autostart.log"
echo "=== $(date) autostart begin ===" >> $LOG

# ---------- 环境变量（显式声明，不依赖 ~/.bashrc）----------
# 非交互 shell（cron 的 @reboot、ssh 主机 "命令"）下，Ubuntu 默认 ~/.bashrc 开头的
#   case $- in *i*) ;; *) return;; esac
# 守卫会直接 return，排在文件末尾的那组 export 根本不会执行 ——
# 此时 $HADOOP_HOME 为空，下面的启动命令会塌成 /sbin/start-dfs.sh 并静默失败。
# 所以这里显式声明；路径已在本机 VM 上确认（/opt/hadoop、/opt/hbase）。
export JAVA_HOME=${JAVA_HOME:-/usr/lib/jvm/java-11-openjdk-amd64}
export HADOOP_HOME=${HADOOP_HOME:-/opt/hadoop}
export HBASE_HOME=${HBASE_HOME:-/opt/hbase}
# 这三个 Hadoop 客户端变量不能少：Spring Boot 侧连 HBase 要读 HADOOP_CONF_DIR，
# 缺了会在打包/启动阶段报找不到 hbase-site.xml。
export HADOOP_HDFS_HOME=${HADOOP_HDFS_HOME:-$HADOOP_HOME}
export HADOOP_CONF_DIR=${HADOOP_CONF_DIR:-$HADOOP_HOME/etc/hadoop}
export HADOOP_COMMON_LIB_NATIVE_DIR=${HADOOP_COMMON_LIB_NATIVE_DIR:-$HADOOP_HOME/lib/native}
export PATH=$JAVA_HOME/bin:$HADOOP_HOME/bin:$HADOOP_HOME/sbin:$HBASE_HOME/bin:$PATH

# 1. Hadoop (HDFS + YARN)
echo ">>> start hadoop" >> $LOG
$HADOOP_HOME/sbin/start-dfs.sh >> $LOG 2>&1
$HADOOP_HOME/sbin/start-yarn.sh >> $LOG 2>&1
sleep 8

# 2. HBase + Thrift
echo ">>> start hbase" >> $LOG
$HBASE_HOME/bin/start-hbase.sh >> $LOG 2>&1
sleep 5
$HBASE_HOME/bin/hbase-daemon.sh start thrift >> $LOG 2>&1
sleep 3

# 3. Spring Boot（幂等：已在监听 8080 就跳过，避免重复实例抢端口）
echo ">>> start spring boot" >> $LOG
if ss -lnt 2>/dev/null | grep -q ':8080 '; then
    echo ">>> spring boot already listening on 8080, skip" >> $LOG
else
    cd "$HOME/day08"
    # account_env.sh 提供 JWT_SECRET / SMTP 等可选安全配置（没有它 Spring Boot 用自带默认值启动）。
    # 必须容错：一个可选配置文件不该让整个开机自启中断（原写法 `|| exit 1` 很危险）。
    if [ -f "$HOME/day08/deploy/run/account_env.sh" ]; then
        # shellcheck disable=SC1090
        . "$HOME/day08/deploy/run/account_env.sh"
    fi
    nohup java -jar target/demo-0.0.1-SNAPSHOT.jar > app.log 2>&1 < /dev/null &
    echo $! > "$HOME/day08/app.pid"
fi

# 4. predict 服务 (cron 已有独立 @reboot, 这里兜底, pkill 避免重复)
pkill -f serve_api 2>/dev/null
sleep 1
cd "$HOME/predict"
# 部署脚本把 predict 的依赖装在 .venv 里，优先用它；没有才回退系统 python3
PREDICT_PY="python3"
[ -x "$HOME/predict/.venv/bin/python" ] && PREDICT_PY="$HOME/predict/.venv/bin/python"
nohup "$PREDICT_PY" serve_api.py 8788 >> predict.log 2>&1 < /dev/null &

echo "=== $(date) autostart done ===" >> $LOG
