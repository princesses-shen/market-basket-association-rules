# -*- coding: utf-8 -*-
"""
增量补齐岗位数据的城市覆盖（不删表、不动现有记录）
====================================================
背景
----
前端 GET /api/job/cities 是「直接从 recruit_job 全表去重取城市」，而库中
现有记录只覆盖 15 个城市，导致城市下拉框偏少。

仓库里的 scripts/gen_data.py 虽然自带 51 城池，但它会
    disable_table + delete_table + create_table
整张重建 recruit_job / recruit_user —— 会连带清空企业账号、已投递简历、
人才库等真实数据。因此**不能直接重跑它**。

本脚本只做增量：
  1. 读 recruit_job 现有全表，统计各城市条数；
  2. 按与 gen_data.py 同一份 51 城池，给不足目标的城市补记录；
  3. rowkey 从 job_02001 起递增，避开现有编号
     （job_00001~job_01200 及企业发布的时间戳 rowkey）；
  4. 写入字段与现有记录完全一致的 12 列（含 company_tier）；
  5. 写入后从全表重新聚合，刷新 recruit_position / recruit_salary /
     recruit_keyword 三张统计表（大屏数据源）。

用法（在装有 happybase 的机器上执行）
----
  python3 scripts/expand_cities.py --dry-run    # 只统计与预演，不写库
  python3 scripts/expand_cities.py              # 实际写入
  python3 scripts/expand_cities.py --per-city 90  # 指定每城目标条数（固定值）
"""
import argparse
import os
import random
import sys
from collections import Counter
from datetime import datetime, timedelta

import happybase

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

HOST = os.environ.get("HBASE_HOST", "192.168.92.128")
PORT = int(os.environ.get("HBASE_PORT", "9090"))
CF = "info"
JOB_TABLE = "recruit_job"
ROWKEY_START = 2001          # 现有 seeds 占到 job_01200，从其后续编
OWNER_SAFE_GAP = 1900        # 与现有 rowkey 的缓冲

# ---------------------------------------------------------------- 数据池
# 与 scripts/gen_data.py 保持同一份 51 城池
CITIES = ["北京", "上海", "广州", "深圳", "杭州", "成都", "南京", "武汉", "西安", "长沙",
          "苏州", "重庆", "天津", "青岛", "厦门", "宁波", "郑州", "合肥", "福州", "济南",
          "大连", "沈阳", "长春", "哈尔滨", "石家庄", "太原", "南昌", "南宁", "昆明", "贵阳",
          "兰州", "西宁", "银川", "乌鲁木齐", "呼和浩特", "海口", "三亚", "珠海", "东莞", "佛山",
          "无锡", "常州", "南通", "徐州", "温州", "绍兴", "嘉兴", "泉州", "烟台", "潍坊", "洛阳"]

TITLES = ["Java开发工程师", "Python开发工程师", "前端开发工程师", "后端开发工程师", "全栈工程师",
          "数据分析师", "算法工程师", "测试工程师", "运维工程师", "DevOps工程师",
          "产品经理", "UI设计师", "项目经理", "大数据工程师", "机器学习工程师",
          "Go开发工程师", "Android开发", "iOS开发", "数据库工程师", "安全工程师"]

COMPANIES = ["字节跳动", "腾讯", "阿里巴巴", "百度", "美团", "京东", "网易", "小米", "华为",
             "拼多多", "快手", "滴滴", "携程", "哔哩哔哩", "蚂蚁集团", "菜鸟网络",
             "大疆创新", "商汤科技", "旷视科技", "地平线", "蔚来汽车", "理想汽车",
             "小红书", "知乎", "链家", "贝壳找房", "同程旅行", "58同城", "新浪微博", "搜狐"]

EDUS = ["不限", "大专", "本科", "本科", "本科", "硕士"]
EXPS = ["应届", "1年", "1-3年", "1-3年", "3-5年", "3-5年", "5-10年", "不限"]
CATEGORIES = ["后端开发", "前端开发", "移动开发", "测试", "运维", "数据", "算法", "产品", "设计", "安全"]
TAGS_POOL = ["Java", "Python", "Go", "React", "Vue", "Spring", "MySQL", "Redis", "Docker",
             "Kubernetes", "Linux", "Hadoop", "Spark", "Flink", "Kafka", "ElasticSearch",
             "TensorFlow", "PyTorch", "微服务", "分布式", "高并发", "机器学习", "深度学习"]
SALARY_RANGES = [(5, 10), (8, 15), (10, 20), (15, 25), (15, 30), (20, 35), (25, 40), (30, 50), (35, 60)]

# 与 src/ingest/company_tier.py 同一份规则（内联，避免依赖相对路径）
HEAD_BIG = {"阿里巴巴", "腾讯", "字节跳动", "百度", "华为", "京东", "小米", "美团", "拼多多", "滴滴",
            "网易", "快手", "bilibili", "哔哩哔哩", "蚂蚁集团", "蚂蚁金服", "菜鸟", "奇虎360", "360",
            "新浪", "搜狐", "携程", "去哪儿", "同程", "58同城", "58", "大疆", "海康威视", "科大讯飞",
            "联想", "中兴", "中国移动", "中国电信", "中国联通", "工商银行", "建设银行", "中国银行",
            "农业银行", "平安", "招商银行", "泰康", "泰康人寿", "新东方", "好未来", "学而思",
            "完美世界", "巨人网络", "米哈游", "叠纸", "莉莉丝", "鹰角", "沐瞳", "funplus", "趣加",
            "欢聚时代", "虎牙", "斗鱼", "小红书", "得物", "shein", "希音", "微众银行", "网商银行",
            "广发证券", "华泰证券", "中信证券", "国泰君安"}

MID_BIG = {"IBM", "微软", "谷歌", "Google", "亚马逊", "Amazon", "苹果", "Apple", "Facebook", "Meta",
           "英特尔", "Intel", "甲骨文", "Oracle", "思科", "Cisco", "戴尔", "惠普", "HP", "SAP",
           "埃森哲", "Thoughtworks", "VMware", "红帽", "RedHat", "联想集团", "美的", "格力", "海尔",
           "海信", "TCL", "康佳", "长虹", "OPPO", "vivo", "传音", "realme", "一加", "荣耀",
           "中通", "圆通", "申通", "韵达", "顺丰", "京东物流", "苏宁", "国美", "永辉", "大润发",
           "家乐福", "沃尔玛", "麦当劳", "肯德基", "星巴克", "可口可乐", "百事", "宝洁", "联合利华",
           "欧莱雅", "雀巢", "茅台", "五粮液", "比亚迪", "蔚来", "理想汽车", "小鹏", "吉利", "长城"}


def infer_tier(company):
    """根据公司名推断档次，规则与 src/ingest/company_tier.py 一致。"""
    if not company:
        return "中小-初创"
    company = company.strip()
    for name in HEAD_BIG:
        if name in company:
            return "头部大厂"
    for name in MID_BIG:
        if name in company:
            return "中大型企业"
    if any(kw in company for kw in ["有限公司", "股份", "集团", "科技有限"]):
        return "成长型企业"
    return "中小-初创"


def gen_desc(title, company, city, edu, exp):
    """岗位描述模板，与 scripts/gen_data.py 完全一致。"""
    return (f"【岗位名称】{title}\n"
            f"【工作地点】{city}\n"
            f"【学历要求】{edu}\n"
            f"【经验要求】{exp}\n\n"
            f"岗位职责：\n1. 负责{company}相关产品的技术架构和开发；\n"
            f"2. 参与系统设计，保证系统的高可用性和高性能；\n"
            f"3. 与团队协作，按时交付高质量代码。\n\n"
            f"任职要求：\n1. {edu}及以上学历，{exp}相关工作经验；\n"
            f"2. 熟悉常用的开发框架和工具；\n3. 良好的沟通能力和团队合作精神；\n"
            f"4. 有大型互联网公司经验者优先。")


def gen_job(city, rowkey, now, rng):
    """生成一条岗位记录，字段与现有 12 列对齐（不含 owner/status）。"""
    title = rng.choice(TITLES)
    company = rng.choice(COMPANIES)
    edu = rng.choice(EDUS)
    exp = rng.choice(EXPS)
    sal = rng.choice(SALARY_RANGES)
    category = rng.choice(CATEGORIES)
    tags = rng.sample(TAGS_POOL, rng.randint(3, 6))
    pub = (now - timedelta(days=rng.randint(0, 29),
                           hours=rng.randint(0, 23))).strftime("%Y-%m-%d %H:%M")
    return rowkey, {
        f"{CF}:title": title,
        f"{CF}:city": city,
        f"{CF}:salary_low": str(sal[0]),
        f"{CF}:salary_high": str(sal[1]),
        f"{CF}:company": company,
        f"{CF}:company_tier": infer_tier(company),
        f"{CF}:edu": edu,
        f"{CF}:exp": exp,
        f"{CF}:category": category,
        f"{CF}:tags": ";".join(tags),
        f"{CF}:desc": gen_desc(title, company, city, edu, exp),
        f"{CF}:publish_time": pub,
    }


def salary_bucket(low):
    """薪资分箱，标签沿用库中 recruit_salary 表现有口径。"""
    if low < 5:
        return "0-5K"
    if low < 10:
        return "5-10K"
    if low < 15:
        return "10-15K"
    if low < 20:
        return "15-20K"
    if low < 25:
        return "20-25K"
    if low < 30:
        return "25-30K"
    return "30K以上"


def refresh_stats(conn, jobs, dry_run=False):
    """从 recruit_job 全表重新聚合，刷新三张统计表（派生数据，可安全重建）。"""
    position = Counter()
    salary = Counter()
    keyword = Counter()
    for j in jobs:
        if j.get("city"):
            position[j["city"]] += 1
        try:
            salary[salary_bucket(int(j.get("salary_low", 0)))] += 1
        except (TypeError, ValueError):
            pass
        for t in str(j.get("tags", "")).split(";"):
            t = t.strip()
            if t:
                keyword[t] += 1

    print("\n[聚合] recruit_position : %d 个城市" % len(position))
    print("[聚合] recruit_salary   : %d 档" % len(salary))
    print("[聚合] recruit_keyword  : %d 个关键词" % len(keyword))
    if dry_run:
        return position, salary, keyword

    def rebuild(name, mapping, column):
        existing = [t.decode() if isinstance(t, bytes) else t for t in conn.tables()]
        if name in existing:
            conn.disable_table(name)
            conn.delete_table(name)
        t = conn.create_table(name, {CF: dict()})
        t = conn.table(name)
        with t.batch(batch_size=500) as b:
            for k, v in mapping.items():
                b.put(k, {f"{CF}:{column}": str(v)})
        print("  [重建] %-20s %d 行" % (name, len(mapping)))

    rebuild("recruit_position", position, "position_count")
    rebuild("recruit_salary", salary, "count")
    rebuild("recruit_keyword", keyword, "count")
    return position, salary, keyword


def main():
    ap = argparse.ArgumentParser(description="增量补齐 51 城岗位数据")
    ap.add_argument("--dry-run", action="store_true", help="只统计与预演，不写库")
    ap.add_argument("--per-city", type=int, default=0,
                    help="每城目标条数（固定值）；不填则按 70~100 随机")
    ap.add_argument("--seed", type=int, default=20260918, help="随机种子，便于复现")
    args = ap.parse_args()

    rng = random.Random(args.seed)

    print(">>> 连接 HBase %s:%d ..." % (HOST, PORT))
    conn = happybase.Connection(HOST, PORT, timeout=60000)
    table = conn.table(JOB_TABLE)

    # ---------- 1. 读现有数据 ----------
    existing = Counter()
    existing_keys = set()
    total_before = 0
    for k, d in table.scan(columns=[f"{CF}:city"]):
        total_before += 1
        existing_keys.add(k.decode())
        existing[d.get(f"{CF}:city".encode(), b"").decode()] += 1

    unknown = sorted(set(existing) - set(CITIES) - {""})
    print(">>> 现有 recruit_job: %d 行 / %d 个城市" % (total_before, len(existing)))
    if unknown:
        print("    [提示] 库中存在池外的城市（保留不动）: %s" % "、".join(unknown))

    # ---------- 2. 制定补齐计划 ----------
    targets = {c: (args.per_city if args.per_city > 0 else rng.randint(70, 100)) for c in CITIES}
    plan = []
    for city in CITIES:
        need = max(0, targets[city] - existing.get(city, 0))
        if need:
            plan.append((city, existing.get(city, 0), targets[city], need))

    add_total = sum(p[3] for p in plan)
    print(">>> 待补城市 %d 个，预计新增 %d 条" % (len(plan), add_total))
    print("    目标城市总数 = %d（现有 %d 个，补齐后应为 %d 个）"
          % (len(CITIES), len(set(CITIES) & set(existing)), len(CITIES)))

    # rowkey 冲突检查
    keys_planned = ["job_%05d" % (ROWKEY_START + i) for i in range(add_total)]
    conflict = sorted(set(keys_planned) & existing_keys)
    print("    rowkey 区间: %s ~ %s，与现有冲突: %d 个"
          % (keys_planned[0], keys_planned[-1], len(conflict)))
    if conflict:
        print("    [ERROR] rowkey 冲突，已中止。请调整 ROWKEY_START。")
        conn.close()
        sys.exit(1)

    if args.dry_run:
        print("\n===== DRY-RUN：以下为待补明细（不写库）=====")
        for city, have, want, need in plan[:12]:
            print("    %-8s 现有 %3d → 目标 %3d，补 %3d" % (city, have, want, need))
        if len(plan) > 12:
            print("    ... 其余 %d 个城市略" % (len(plan) - 12))
        print("\n[DRY-RUN] 未写入任何数据。")
        conn.close()
        return

    # ---------- 3. 写入 ----------
    now = datetime.now()
    idx = ROWKEY_START
    written = 0
    with table.batch(batch_size=500) as b:
        for city, have, want, need in plan:
            for _ in range(need):
                rowkey, data = gen_job(city, "job_%05d" % idx, now, rng)
                b.put(rowkey, data)
                idx += 1
                written += 1
    print("\n>>> 已写入 %d 条新岗位" % written)

    # ---------- 4. 校验原有数据完好 ----------
    after = {}
    for k, d in table.scan(columns=[f"{CF}:city"]):
        after[k.decode()] = d.get(f"{CF}:city".encode(), b"").decode()
    lost = existing_keys - set(after)
    print(">>> 写入后总行数 = %d（原 %d + 新增 %d = %d）"
          % (len(after), total_before, written, total_before + written))
    if lost:
        print("    [ERROR] 原有 %d 条记录丢失: %s" % (len(lost), sorted(lost)[:5]))
        conn.close()
        sys.exit(2)
    print("    [OK] 原有 %d 条记录全部完好" % total_before)

    # ---------- 5. 刷新统计表 ----------
    jobs = []
    for k, d in table.scan(columns=[f"{CF}:city", f"{CF}:salary_low", f"{CF}:tags"]):
        jobs.append({
            "city": d.get(f"{CF}:city".encode(), b"").decode(),
            "salary_low": d.get(f"{CF}:salary_low".encode(), b"0").decode(),
            "tags": d.get(f"{CF}:tags".encode(), b"").decode(),
        })
    position, _, _ = refresh_stats(conn, jobs)

    conn.close()
    print("\n>>> 完成。recruit_job 共 %d 行 / %d 个城市" % (len(after), len(position)))


if __name__ == "__main__":
    main()
